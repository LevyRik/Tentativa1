import { pgTable, text, serial, integer, boolean, timestamp, date, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Student table
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  registrationNumber: text("registration_number").notNull().unique(),
  avatarUrl: text("avatar_url"),
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

// Attendance record table
export const attendanceRecords = pgTable("attendance_records", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  date: date("date").notNull(),
  status: text("status").notNull(), // "present", "absent", "justified"
  period: text("period"), // Indica qual período/aula do dia: "1", "2", "3", "4", "5"
});

export const insertAttendanceRecordSchema = createInsertSchema(attendanceRecords).omit({
  id: true,
});

// Class Schedule table
export const classSchedules = pgTable("class_schedules", {
  id: serial("id").primaryKey(),
  dayOfWeek: text("day_of_week").notNull(), // "monday", "tuesday", etc.
  subject: text("subject").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
});

export const insertClassScheduleSchema = createInsertSchema(classSchedules).omit({
  id: true,
});

// Export types
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type InsertAttendanceRecord = z.infer<typeof insertAttendanceRecordSchema>;

export type ClassSchedule = typeof classSchedules.$inferSelect;
export type InsertClassSchedule = z.infer<typeof insertClassScheduleSchema>;

// Create schemas for validating student status updates
export const attendanceStatusSchema = z.enum(["present", "absent", "justified"]);
export type AttendanceStatus = z.infer<typeof attendanceStatusSchema>;

// For bulk attendance recording
export const bulkAttendanceSchema = z.array(
  z.object({
    studentId: z.number(),
    status: attendanceStatusSchema,
  })
);
export type BulkAttendance = z.infer<typeof bulkAttendanceSchema>;
