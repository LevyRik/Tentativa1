import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from "fs";
import path from "path";
import archiver from "archiver";
import { 
  insertStudentSchema, 
  attendanceStatusSchema,
  bulkAttendanceSchema,
  insertAttendanceRecordSchema,
  insertClassScheduleSchema,
  type InsertAttendanceRecord
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Students API
  app.get("/api/students", async (_req: Request, res: Response) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const student = await storage.getStudent(id);
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  app.post("/api/students", async (req: Request, res: Response) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid student data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create student" });
    }
  });

  app.put("/api/students/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertStudentSchema.partial().parse(req.body);
      
      const student = await storage.updateStudent(id, validatedData);
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid student data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteStudent(id);
      
      if (!success) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete student" });
    }
  });

  // Attendance API
  app.get("/api/attendance", async (req: Request, res: Response) => {
    try {
      const dateStr = req.query.date as string | undefined;
      const period = req.query.period as string | undefined;
      let date: Date | undefined = undefined;
      
      if (dateStr) {
        date = new Date(dateStr);
      }
      
      const records = await storage.getAttendanceRecords(date);
      
      // Filtrar por período, se especificado
      if (period) {
        const filteredRecords = records.filter(record => record.period === period);
        return res.json(filteredRecords);
      }
      
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance records" });
    }
  });
  
  // Histórico de chamadas
  app.get("/api/attendance/history", async (req: Request, res: Response) => {
    try {
      const studentId = req.query.studentId ? parseInt(req.query.studentId as string) : undefined;
      const records = await storage.getAttendanceRecords();
      
      // Agrupamento e formatação do histórico
      const historyData: {
        date: string;
        period: string | null;
        totalStudents: number;
        presentCount: number;
        absentCount: number;
        justifiedCount: number;
        attendancePercent: number;
      }[] = [];
      
      const recordsByDate = new Map<string, Map<string, any[]>>();
      
      // Agrupar registros por data e período
      for (const record of records) {
        // Filtrar por estudante se necessário
        if (studentId && record.studentId !== studentId) {
          continue;
        }
        
        const dateStr = new Date(record.date).toISOString().split('T')[0];
        
        if (!recordsByDate.has(dateStr)) {
          recordsByDate.set(dateStr, new Map());
        }
        
        const periodsMap = recordsByDate.get(dateStr)!;
        const period = record.period || 'default';
        
        if (!periodsMap.has(period)) {
          periodsMap.set(period, []);
        }
        
        periodsMap.get(period)!.push(record);
      }
      
      // Converter para formato apropriado para o front-end
      recordsByDate.forEach((periodsMap, dateStr) => {
        periodsMap.forEach((periodRecords, period) => {
          const totalStudents = periodRecords.length;
          const presentCount = periodRecords.filter(r => r.status === 'present').length;
          const absentCount = periodRecords.filter(r => r.status === 'absent').length;
          const justifiedCount = periodRecords.filter(r => r.status === 'justified').length;
          
          historyData.push({
            date: dateStr,
            period: period !== 'default' ? period : null,
            totalStudents,
            presentCount,
            absentCount,
            justifiedCount,
            attendancePercent: totalStudents > 0 ? Math.round((presentCount / totalStudents) * 100) : 0
          });
        });
      });
      
      // Ordenar por data (mais recentes primeiro)
      historyData.sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return dateB.getTime() - dateA.getTime();
      });
      
      res.json(historyData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance history" });
    }
  });

  app.get("/api/attendance/student/:studentId", async (req: Request, res: Response) => {
    try {
      const studentId = parseInt(req.params.studentId);
      const records = await storage.getStudentAttendance(studentId);
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student attendance" });
    }
  });

  app.post("/api/attendance", async (req: Request, res: Response) => {
    try {
      const validatedData = insertAttendanceRecordSchema.parse(req.body);
      const record = await storage.recordAttendance(validatedData);
      res.status(201).json(record);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid attendance data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to record attendance" });
    }
  });

  app.post("/api/attendance/bulk", async (req: Request, res: Response) => {
    try {
      const validatedData = bulkAttendanceSchema.parse(req.body.attendances);
      const date = new Date(req.body.date);
      const period = req.body.period; // Adicionar período
      
      if (isNaN(date.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      const results = [];
      
      for (const attendance of validatedData) {
        const record: InsertAttendanceRecord = {
          studentId: attendance.studentId,
          date,
          status: attendance.status,
          period: period || null // Adicionar período
        };
        
        const result = await storage.recordAttendance(record);
        results.push(result);
      }
      
      res.status(201).json(results);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid attendance data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to record attendance" });
    }
  });

  app.put("/api/attendance/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedStatus = attendanceStatusSchema.parse(req.body.status);
      
      const record = await storage.updateAttendanceRecord(id, validatedStatus);
      
      if (!record) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      
      res.json(record);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid status", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update attendance record" });
    }
  });

  app.get("/api/attendance/stats", async (_req: Request, res: Response) => {
    try {
      const stats = await storage.getAttendanceStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance statistics" });
    }
  });

  // Class Schedule API
  app.get("/api/schedule", async (_req: Request, res: Response) => {
    try {
      const schedules = await storage.getClassSchedules();
      res.json(schedules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch class schedules" });
    }
  });

  app.post("/api/schedule", async (req: Request, res: Response) => {
    try {
      const validatedData = insertClassScheduleSchema.parse(req.body);
      const schedule = await storage.createClassSchedule(validatedData);
      res.status(201).json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid schedule data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create class schedule" });
    }
  });

  app.put("/api/schedule/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertClassScheduleSchema.partial().parse(req.body);
      
      const schedule = await storage.updateClassSchedule(id, validatedData);
      
      if (!schedule) {
        return res.status(404).json({ message: "Class schedule not found" });
      }
      
      res.json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid schedule data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update class schedule" });
    }
  });

  app.delete("/api/schedule/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteClassSchedule(id);
      
      if (!success) {
        return res.status(404).json({ message: "Class schedule not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete class schedule" });
    }
  });

  // Download API
  app.get("/api/download/source", (_req: Request, res: Response) => {
    const archive = archiver('zip', {
      zlib: { level: 9 } // Maximum compression
    });
    
    // Set appropriate headers
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename=sistema_chamada_source.zip');
    
    // Pipe archive data to the response
    archive.pipe(res);
    
    const rootDir = process.cwd();
    
    // Add directories to the archive
    const directoriesToInclude = ['client', 'server', 'shared'];
    directoriesToInclude.forEach(dir => {
      archive.directory(path.join(rootDir, dir), dir);
    });
    
    // Add individual files to the archive
    const filesToInclude = [
      'capacitor.config.ts',
      'components.json',
      'drizzle.config.ts',
      'postcss.config.js',
      'tailwind.config.ts',
      'tsconfig.json',
      'vite.config.ts',
      'build-apk.sh'
    ];
    
    filesToInclude.forEach(file => {
      const filePath = path.join(rootDir, file);
      if (fs.existsSync(filePath)) {
        archive.file(filePath, { name: file });
      }
    });
    
    // Finalize the archive and send
    archive.finalize();
  });

  app.get("/api/download/apk", (_req: Request, res: Response) => {
    // Provide APK build instructions in a more detailed format
    const instructions = `
# Instruções para Geração do APK do Sistema de Chamada

Este sistema foi configurado para ser convertido para um aplicativo Android usando Capacitor.js.
Devido às limitações de recursos e tempo no ambiente Replit, o APK não pode ser gerado diretamente aqui.

## Passos para gerar o APK em seu próprio ambiente:

1. Faça o download do código-fonte através da opção "Código-fonte" no menu de download.

2. Descompacte o arquivo ZIP baixado em seu computador.

3. Instale as dependências necessárias:
   - Node.js (versão 16 ou superior)
   - Android Studio (para build Android)
   - JDK 11 ou superior

4. Abra um terminal na pasta do projeto e execute:
   \`\`\`
   npm install
   npm run build
   npx cap init "Sistema de Chamada" com.attendance.app --web-dir client/dist
   npx cap add android
   npx cap sync
   \`\`\`

5. Abra o projeto Android gerado no Android Studio:
   \`\`\`
   npx cap open android
   \`\`\`

6. No Android Studio, selecione "Build > Build Bundle(s) / APK(s) > Build APK(s)".

7. O APK estará disponível em 'android/app/build/outputs/apk/debug/app-debug.apk'.

Observação: O sistema foi projetado para funcionar tanto como webapp quanto como aplicativo nativo Android.
    `;
    
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=instrucoes-apk.txt');
    res.send(instructions);
  });

  const httpServer = createServer(app);
  return httpServer;
}
