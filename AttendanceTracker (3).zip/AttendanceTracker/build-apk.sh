#!/bin/bash

# Script para construir e gerar um APK do aplicativo de presença

echo "Iniciando processo de construção do APK..."

# Construir a aplicação web
echo "Construindo a aplicação web com Vite..."
npm run build

# Inicializar Capacitor se ainda não foi feito
if [ ! -d "android" ]; then
    echo "Inicializando Capacitor..."
    npx cap init "Sistema de Chamada" com.attendance.app --web-dir client/dist
    
    echo "Adicionando plataforma Android..."
    npx cap add android
fi

# Sincronizar a build com Capacitor
echo "Sincronizando a build com Capacitor..."
npx cap sync

# Copiar arquivos para a plataforma Android
echo "Copiando arquivos para Android..."
npx cap copy android

# Navegar para o diretório Android e construir o APK
echo "Construindo o APK..."
cd android && ./gradlew assembleDebug

# Verificar se o APK foi gerado com sucesso
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "APK gerado com sucesso!"
    # Copiar o APK para a raiz do projeto
    cp app/build/outputs/apk/debug/app-debug.apk ../sistema-chamada.apk
    cd ..
    echo "O APK está disponível em: sistema-chamada.apk"
else
    echo "Erro ao gerar o APK."
    cd ..
fi