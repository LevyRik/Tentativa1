import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Student, AttendanceRecord, AttendanceStatus } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar as CalendarIcon, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { AttendanceHistory } from "@/components/AttendanceHistory";

export default function Attendance() {
  const { toast } = useToast();
  const [date, setDate] = useState<Date>(new Date());
  const [openCalendar, setOpenCalendar] = useState(false);
  const [attendances, setAttendances] = useState<Map<number, AttendanceStatus>>(new Map());
  const [selectedPeriod, setSelectedPeriod] = useState<string>("1");

  // Query for students
  const { data: students, isLoading: isLoadingStudents } = useQuery<Student[]>({
    queryKey: ["/api/students"]
  });

  // Query for attendance records for the selected date and period
  const { data: attendanceRecords, isLoading: isLoadingAttendance } = useQuery<AttendanceRecord[]>({
    queryKey: ["/api/attendance", format(date, 'yyyy-MM-dd'), selectedPeriod],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`/api/attendance?date=${queryKey[1]}&period=${queryKey[2]}`);
      if (!response.ok) throw new Error('Failed to fetch attendance');
      return response.json();
    }
  });

  // Mutation for saving attendance
  const saveAttendanceMutation = useMutation({
    mutationFn: async () => {
      const attendanceData = Array.from(attendances.entries()).map(([studentId, status]) => ({
        studentId,
        status
      }));

      return apiRequest("POST", "/api/attendance/bulk", {
        date: date.toISOString(),
        period: selectedPeriod,
        attendances: attendanceData
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Presença registrada com sucesso!"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/attendance/stats"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao registrar presença. Tente novamente.",
        variant: "destructive"
      });
    }
  });

  // Initialize attendances from records when data is loaded
  useEffect(() => {
    if (attendanceRecords && students) {
      const newAttendances = new Map<number, AttendanceStatus>();
      
      // Set default value for all students as "present"
      students.forEach(student => {
        newAttendances.set(student.id, "present");
      });
      
      // Update with actual values from records
      attendanceRecords.forEach(record => {
        newAttendances.set(record.studentId, record.status as AttendanceStatus);
      });
      
      setAttendances(newAttendances);
    }
  }, [attendanceRecords, students]);

  // Handle attendance status change
  const handleStatusChange = (studentId: number, status: AttendanceStatus) => {
    setAttendances(prev => {
      const updated = new Map(prev);
      updated.set(studentId, status);
      return updated;
    });
  };

  // Handle save button click
  const handleSave = () => {
    saveAttendanceMutation.mutate();
  };

  return (
    <div className="space-y-6">
      {/* Histórico de chamadas */}
      <div className="bounce-in">
        <AttendanceHistory />
      </div>
      
      {/* Formulário de registro de presença */}
      <div className="bg-card shadow rounded-lg p-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
          <div>
            <h2 className="text-xl gradient-heading mb-1">Registro de Presença</h2>
            <div className="text-sm text-muted-foreground">Marque a presença dos alunos por aula</div>
          </div>
          <div className="mt-3 sm:mt-0 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
            <Popover open={openCalendar} onOpenChange={setOpenCalendar}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-[180px] justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {format(date, "dd/MM/yyyy")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={(newDate) => {
                    if (newDate) {
                      setDate(newDate);
                      setOpenCalendar(false);
                    }
                  }}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            
            <Select
              value={selectedPeriod}
              onValueChange={setSelectedPeriod}
            >
              <SelectTrigger className="w-[180px]">
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Selecione o período" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1ª Aula (07:00 - 08:00)</SelectItem>
                <SelectItem value="2">2ª Aula (08:00 - 09:00)</SelectItem>
                <SelectItem value="3">3ª Aula (09:15 - 10:15)</SelectItem>
                <SelectItem value="4">4ª Aula (10:15 - 11:15)</SelectItem>
                <SelectItem value="5">5ª Aula (11:15 - 12:15)</SelectItem>
              </SelectContent>
            </Select>
            
            <Button 
              onClick={handleSave}
              disabled={saveAttendanceMutation.isPending || isLoadingStudents || isLoadingAttendance}
              className="bg-accent hover:bg-accent/90"
            >
              {saveAttendanceMutation.isPending ? "Salvando..." : "Salvar Chamada"}
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          {isLoadingStudents || isLoadingAttendance ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map(i => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : students?.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              Nenhum aluno cadastrado. Adicione alunos na aba "Alunos".
            </div>
          ) : (
            <table className="min-w-full divide-y divide-border">
              <thead className="bg-muted/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Aluno</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {students?.map(student => (
                  <tr key={student.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                          {student.avatarUrl ? (
                            <img 
                              className="h-10 w-10 rounded-full" 
                              src={student.avatarUrl} 
                              alt={`Foto de ${student.name}`}
                            />
                          ) : (
                            <span className="text-sm font-semibold text-primary">
                              {student.name.charAt(0)}
                            </span>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium">{student.name}</div>
                          <div className="text-xs text-muted-foreground">RA: {student.registrationNumber}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <RadioGroup 
                        value={attendances.get(student.id) || "present"}
                        onValueChange={(value: string) => handleStatusChange(student.id, value as AttendanceStatus)}
                        className="flex items-center space-x-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="present" id={`present-${student.id}`} className="text-green-600" />
                          <Label htmlFor={`present-${student.id}`} className="text-sm">Presente</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="absent" id={`absent-${student.id}`} className="text-red-600" />
                          <Label htmlFor={`absent-${student.id}`} className="text-sm">Falta</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="justified" id={`justified-${student.id}`} className="text-amber-600" />
                          <Label htmlFor={`justified-${student.id}`} className="text-sm">Justificada</Label>
                        </div>
                      </RadioGroup>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
