import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Search, Plus } from "lucide-react";
import { StudentDialog } from "@/components/StudentDialog";
import { Student, AttendanceRecord } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function Students() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | undefined>(undefined);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingStudentId, setDeletingStudentId] = useState<number | null>(null);

  // Fetch students
  const { data: students, isLoading: isLoadingStudents } = useQuery<Student[]>({
    queryKey: ["/api/students"]
  });

  // Fetch attendance records (to get absence counts)
  const { data: attendanceRecords, isLoading: isLoadingAttendance } = useQuery<AttendanceRecord[]>({
    queryKey: ["/api/attendance"]
  });

  // Delete student mutation
  const deleteStudentMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/students/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Aluno removido com sucesso."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao remover o aluno. Tente novamente.",
        variant: "destructive"
      });
    }
  });

  // Filter students by search query
  const filteredStudents = students?.filter(student => 
    student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.registrationNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Count absences for a student
  const countAbsences = (studentId: number, type: "absent" | "justified" = "absent") => {
    if (!attendanceRecords) return 0;
    return attendanceRecords.filter(record => 
      record.studentId === studentId && record.status === type
    ).length;
  };

  // Handle student edit
  const handleEditStudent = (student: Student) => {
    setEditingStudent(student);
    setAddDialogOpen(true);
  };

  // Handle student delete
  const handleDeleteClick = (studentId: number) => {
    setDeletingStudentId(studentId);
    setDeleteDialogOpen(true);
  };

  // Confirm student delete
  const confirmDelete = () => {
    if (deletingStudentId) {
      deleteStudentMutation.mutate(deletingStudentId);
      setDeleteDialogOpen(false);
      setDeletingStudentId(null);
    }
  };

  // Handle dialog success
  const handleDialogSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/students"] });
    setEditingStudent(undefined);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold">Gerenciar Alunos</h2>
            <div className="mt-1 text-sm text-gray-500">Adicione, edite ou remova alunos da turma</div>
          </div>
          <div className="mt-3 sm:mt-0 flex space-x-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Buscar aluno..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
            </div>
            <Button onClick={() => {
              setEditingStudent(undefined);
              setAddDialogOpen(true);
            }}>
              <Plus className="-ml-1 mr-2 h-5 w-5" />
              Adicionar Aluno
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          {isLoadingStudents || isLoadingAttendance ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map(i => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredStudents?.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              {searchQuery 
                ? "Nenhum aluno encontrado para a pesquisa." 
                : "Nenhum aluno cadastrado. Adicione um aluno clicando no botão acima."}
            </div>
          ) : (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aluno</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RA</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Faltas</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Justificadas</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredStudents?.map(student => (
                  <tr key={student.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                          {student.avatarUrl ? (
                            <img 
                              className="h-10 w-10 rounded-full" 
                              src={student.avatarUrl} 
                              alt={`Foto de ${student.name}`}
                            />
                          ) : (
                            <span className="text-sm font-medium text-gray-500">
                              {student.name.charAt(0)}
                            </span>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium">{student.name}</div>
                          <div className="text-sm text-gray-500">{student.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{student.registrationNumber}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{countAbsences(student.id)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{countAbsences(student.id, "justified")}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button 
                        type="button" 
                        className="text-primary hover:text-primary/80 mr-3"
                        onClick={() => handleEditStudent(student)}
                      >
                        Editar
                      </button>
                      <button 
                        type="button" 
                        className="text-red-600 hover:text-red-800"
                        onClick={() => handleDeleteClick(student.id)}
                      >
                        Remover
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Add/Edit Student Dialog */}
      <StudentDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onSuccess={handleDialogSuccess}
        editingStudent={editingStudent}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Tem certeza?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. Isso removerá permanentemente o aluno e todos os seus registros de presença.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleteStudentMutation.isPending ? "Removendo..." : "Remover"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
