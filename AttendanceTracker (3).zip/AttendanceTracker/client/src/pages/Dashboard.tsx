import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Users, XCircle, CheckCircle, BarChart3 } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { AttendanceChart } from "@/components/AttendanceChart";
import StudentAttendanceReport from "@/components/StudentAttendanceReport";
import { useState } from "react";
import { Student, AttendanceRecord } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Dashboard() {
  const { data: students, isLoading: isLoadingStudents } = useQuery<Student[]>({
    queryKey: ["/api/students"]
  });

  const { data: attendanceRecords, isLoading: isLoadingAttendance } = useQuery<AttendanceRecord[]>({
    queryKey: ["/api/attendance"]
  });

  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/attendance/stats"]
  });

  // Function to determine attendance status badge class
  const getStatusBadgeClass = (status: string) => {
    if (status === "absent") return "bg-red-100 text-red-800";
    if (status === "justified") return "bg-amber-100 text-amber-800";
    return "bg-green-100 text-green-800";
  };

  // Function to get readable status text
  const getStatusText = (status: string) => {
    if (status === "absent") return "Falta";
    if (status === "justified") return "Justificada";
    return "Presente";
  };

  // Mock recent absences for demonstration
  const recentAbsences = attendanceRecords
    ?.filter(record => record.status !== "present")
    .slice(0, 5) || [];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {isLoadingStudents ? (
          <Skeleton className="h-28 w-full" />
        ) : (
          <StatCard
            title="Total de Alunos"
            value={students?.length || 0}
            icon={<Users className="h-6 w-6 text-primary" />}
            colorClass="bg-primary/10"
          />
        )}

        {isLoadingStats ? (
          <Skeleton className="h-28 w-full" />
        ) : (
          <StatCard
            title="Faltas Totais"
            value={stats?.absent || 0}
            icon={<XCircle className="h-6 w-6 text-red-500" />}
            colorClass="bg-red-100"
          />
        )}

        {isLoadingStats ? (
          <Skeleton className="h-28 w-full" />
        ) : (
          <StatCard
            title="Faltas Justificadas"
            value={stats?.justified || 0}
            icon={<CheckCircle className="h-6 w-6 text-amber-500" />}
            colorClass="bg-amber-100"
          />
        )}
      </div>

      {/* Visualizações por tabs */}
      <Tabs defaultValue="chart" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="chart">
            <BarChart3 className="mr-2 h-4 w-4" />
            Estatísticas de Frequência
          </TabsTrigger>
          <TabsTrigger value="report">
            <Users className="mr-2 h-4 w-4" />
            Relatório de Alunos
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="chart" className="space-y-6">
          {/* Attendance Chart */}
          <AttendanceChart />
        </TabsContent>
        
        <TabsContent value="report">
          {/* Student Attendance Report */}
          <StudentAttendanceReport />
        </TabsContent>
      </Tabs>
      
      {/* Recent Absences */}
      <div className="bg-card shadow rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg gradient-heading">Faltas Recentes</h2>
        </div>
        
        <div className="overflow-x-auto">
          {isLoadingAttendance || isLoadingStudents ? (
            <div className="space-y-2">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : recentAbsences.length > 0 ? (
            <table className="min-w-full divide-y divide-border">
              <thead className="bg-muted/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Aluno</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Data</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {recentAbsences.map((record, index) => {
                  const student = students?.find(s => s.id === record.studentId);
                  return (
                    <tr key={record.id} className="hover:bg-muted/20 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-9 w-9 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                            {student?.avatarUrl ? (
                              <img 
                                className="h-9 w-9 rounded-full" 
                                src={student.avatarUrl} 
                                alt={`Foto de ${student.name}`} 
                              />
                            ) : (
                              <span className="text-sm font-semibold text-primary">
                                {student?.name.charAt(0) || "?"}
                              </span>
                            )}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium">{student?.name || "Aluno Desconhecido"}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm">{format(new Date(record.date), 'dd/MM/yyyy')}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          record.status === "absent" ? "attendance-absent" : 
                          record.status === "justified" ? "attendance-justified" : 
                          "attendance-present"
                        }`}>
                          {getStatusText(record.status)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              Não há faltas recentes para exibir.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
