import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

interface DownloadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function DownloadDialog({ open, onOpenChange }: DownloadDialogProps) {
  const handleDownloadSource = () => {
    window.location.href = '/api/download/source';
    onOpenChange(false);
  };

  const handleDownloadApk = () => {
    window.location.href = '/api/download/apk';
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Download</DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          <p className="text-sm text-gray-500 mb-4">Escolha uma opção para download:</p>
          
          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-between h-auto py-3"
              onClick={handleDownloadSource}
            >
              <span className="font-medium">Código-fonte</span>
              <Download className="h-5 w-5 text-primary" />
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-between h-auto py-3"
              onClick={handleDownloadApk}
            >
              <span className="font-medium">APK para Android</span>
              <Download className="h-5 w-5 text-primary" />
            </Button>
          </div>
        </div>
        
        <DialogFooter>
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
          >
            Fechar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
