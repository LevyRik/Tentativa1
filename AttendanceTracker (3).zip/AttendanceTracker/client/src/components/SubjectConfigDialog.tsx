import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { z } from "zod";

interface SubjectConfigDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Schema para validação de configuração de disciplinas
const daySubjectsSchema = z.object({
  subject1: z.string().min(2, "Nome da disciplina é obrigatório").max(100),
  subject2: z.string().min(2, "Nome da disciplina é obrigatório").max(100),
  subject3: z.string().min(2, "Nome da disciplina é obrigatório").max(100),
  subject4: z.string().min(2, "Nome da disciplina é obrigatório").max(100),
  subject5: z.string().min(2, "Nome da disciplina é obrigatório").max(100),
});

const subjectsConfigSchema = z.object({
  monday: daySubjectsSchema,
  tuesday: daySubjectsSchema,
  wednesday: daySubjectsSchema,
  thursday: daySubjectsSchema,
  friday: daySubjectsSchema,
});

type SubjectsConfigFormValues = z.infer<typeof subjectsConfigSchema>;

export function SubjectConfigDialog({ open, onOpenChange }: SubjectConfigDialogProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("monday");
  
  // Valores padrão para o formulário
  const defaultValues: SubjectsConfigFormValues = {
    monday: { 
      subject1: "Matemática", 
      subject2: "Português", 
      subject3: "História", 
      subject4: "Geografia", 
      subject5: "Ciências" 
    },
    tuesday: { 
      subject1: "Português", 
      subject2: "Matemática", 
      subject3: "Ed. Física", 
      subject4: "Artes", 
      subject5: "Inglês" 
    },
    wednesday: { 
      subject1: "História", 
      subject2: "Geografia", 
      subject3: "Matemática", 
      subject4: "Português", 
      subject5: "Ciências" 
    },
    thursday: { 
      subject1: "Ciências", 
      subject2: "Português", 
      subject3: "Matemática", 
      subject4: "Inglês", 
      subject5: "Ed. Física" 
    },
    friday: { 
      subject1: "Matemática", 
      subject2: "Português", 
      subject3: "Artes", 
      subject4: "Ciências", 
      subject5: "Geografia" 
    },
  };
  
  // Recuperar configurações personalizadas do localStorage, se existirem
  const getSavedConfig = (): SubjectsConfigFormValues => {
    const savedConfig = localStorage.getItem('subjectsConfig');
    if (savedConfig) {
      try {
        return JSON.parse(savedConfig);
      } catch (e) {
        console.error("Erro ao ler configurações de disciplinas salvas", e);
      }
    }
    return defaultValues;
  };
  
  const form = useForm<SubjectsConfigFormValues>({
    resolver: zodResolver(subjectsConfigSchema),
    defaultValues: getSavedConfig(),
  });
  
  // Função para salvar as configurações
  const saveSubjectsConfig = async (data: SubjectsConfigFormValues) => {
    setIsLoading(true);
    
    try {
      // Salvar no localStorage
      localStorage.setItem('subjectsConfig', JSON.stringify(data));
      
      // Atualizar o estado da aplicação
      window.dispatchEvent(new CustomEvent('subjectsConfigUpdated', { 
        detail: { subjectsConfig: data } 
      }));
      
      // Notificar usuário
      toast({
        title: "Configurações salvas",
        description: "As disciplinas foram atualizadas com sucesso.",
      });
      
      // Fechar diálogo
      onOpenChange(false);
    } catch (error) {
      console.error("Erro ao salvar configurações", error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar as configurações de disciplinas.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Função para resetar para os valores padrão
  const resetToDefaults = () => {
    form.reset(defaultValues);
    toast({
      title: "Valores padrão",
      description: "As disciplinas foram restauradas para os valores padrão.",
    });
  };
  
  const dayLabels: Record<string, string> = {
    monday: "Segunda-feira",
    tuesday: "Terça-feira",
    wednesday: "Quarta-feira",
    thursday: "Quinta-feira",
    friday: "Sexta-feira",
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="gradient-heading">Configurar Disciplinas</DialogTitle>
          <DialogDescription>
            Personalize as disciplinas para cada dia da semana e período de aula.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(saveSubjectsConfig)} className="space-y-4">
            <Tabs 
              defaultValue="monday" 
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="grid grid-cols-5 w-full">
                <TabsTrigger value="monday">Seg</TabsTrigger>
                <TabsTrigger value="tuesday">Ter</TabsTrigger>
                <TabsTrigger value="wednesday">Qua</TabsTrigger>
                <TabsTrigger value="thursday">Qui</TabsTrigger>
                <TabsTrigger value="friday">Sex</TabsTrigger>
              </TabsList>
              
              {Object.keys(dayLabels).map((day) => (
                <TabsContent key={day} value={day} className="space-y-4">
                  <div className="rounded-md bg-secondary/30 p-4">
                    <h3 className="font-medium mb-2">{dayLabels[day]}</h3>
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name={`${day}.subject1` as any}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>1ª Aula (07:00 - 08:00)</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`${day}.subject2` as any}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>2ª Aula (08:00 - 09:00)</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Separator className="my-2" />
                      <div className="text-xs text-muted-foreground">Intervalo (09:00 - 09:15)</div>
                      <Separator className="my-2" />
                      
                      <FormField
                        control={form.control}
                        name={`${day}.subject3` as any}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>3ª Aula (09:15 - 10:15)</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`${day}.subject4` as any}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>4ª Aula (10:15 - 11:15)</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`${day}.subject5` as any}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>5ª Aula (11:15 - 12:15)</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
            
            <DialogFooter className="flex flex-col sm:flex-row gap-2 mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={resetToDefaults}
              >
                Restaurar Padrão
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                className="ml-auto"
              >
                {isLoading ? "Salvando..." : "Salvar Configurações"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}