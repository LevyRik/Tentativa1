import { useState, ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { DownloadDialog } from "./DownloadDialog";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location, setLocation] = useLocation();
  const [downloadDialogOpen, setDownloadDialogOpen] = useState(false);

  const getTabPath = (tab: string) => {
    switch (tab) {
      case "dashboard": return "/";
      case "attendance": return "/attendance";
      case "students": return "/students";
      case "schedule": return "/schedule";
      default: return "/";
    }
  };

  const isActiveTab = (tab: string) => {
    const path = getTabPath(tab);
    return location === path;
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="bg-card shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <svg 
                className="h-9 w-9 text-primary mr-2" 
                viewBox="0 0 24 24" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
              >
                <path 
                  d="M12 6V12L16 14M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                />
              </svg>
              <h1 className="text-xl gradient-heading">Sistema de Chamada</h1>
            </div>
            
            <div className="flex items-center">
              <button 
                onClick={() => setDownloadDialogOpen(true)}
                className="ml-3 inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-accent hover:bg-accent/90 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent"
              >
                <svg 
                  className="h-4 w-4 mr-1" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth="2" 
                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" 
                  />
                </svg>
                Download
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="bg-card shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto">
            <Link href={getTabPath("dashboard")}>
              <a 
                className={`py-3 px-1 text-sm font-medium cursor-pointer transition-colors ${
                  isActiveTab("dashboard") ? "border-b-2 border-primary text-primary font-semibold" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Dashboard
              </a>
            </Link>
            <Link href={getTabPath("attendance")}>
              <a 
                className={`py-3 px-1 text-sm font-medium cursor-pointer transition-colors ${
                  isActiveTab("attendance") ? "border-b-2 border-primary text-primary font-semibold" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Chamada
              </a>
            </Link>
            <Link href={getTabPath("students")}>
              <a 
                className={`py-3 px-1 text-sm font-medium cursor-pointer transition-colors ${
                  isActiveTab("students") ? "border-b-2 border-primary text-primary font-semibold" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Alunos
              </a>
            </Link>
            <Link href={getTabPath("schedule")}>
              <a 
                className={`py-3 px-1 text-sm font-medium cursor-pointer transition-colors ${
                  isActiveTab("schedule") ? "border-b-2 border-primary text-primary font-semibold" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Horários
              </a>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-8">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-muted-foreground">
            Sistema de Chamada Escolar © {new Date().getFullYear()}. Todos os direitos reservados a Levy.
          </p>
          <div className="flex justify-center mt-2 space-x-4">
            <span className="text-xs text-muted-foreground hover:text-primary transition-colors cursor-pointer">Política de Privacidade</span>
            <span className="text-xs text-muted-foreground hover:text-primary transition-colors cursor-pointer">Termos de Uso</span>
            <span className="text-xs text-muted-foreground hover:text-primary transition-colors cursor-pointer">Contato</span>
          </div>
        </div>
      </footer>

      {/* Download Dialog */}
      <DownloadDialog 
        open={downloadDialogOpen} 
        onOpenChange={setDownloadDialogOpen} 
      />
    </div>
  );
}
