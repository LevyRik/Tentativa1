import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  CalendarDays,
  Users
} from 'lucide-react';

type HistoryEntry = {
  date: string;
  period: string | null;
  totalStudents: number;
  presentCount: number;
  absentCount: number;
  justifiedCount: number;
  attendancePercent: number;
};

export function AttendanceHistory() {
  const [activeTab, setActiveTab] = useState<string>("all");
  
  const { data: historyData, isLoading } = useQuery<HistoryEntry[]>({
    queryKey: ["/api/attendance/history"],
  });
  
  const getPeriodLabel = (period: string | null): string => {
    if (!period) return "Geral";
    
    const periodMap: Record<string, string> = {
      "1": "1ª Aula (07:00 - 07:50)",
      "2": "2ª Aula (07:50 - 08:40)",
      "3": "3ª Aula (08:40 - 09:30)",
      "4": "4ª Aula (09:50 - 10:40)",
      "5": "5ª Aula (10:40 - 11:30)"
    };
    
    return periodMap[period] || `Aula ${period}`;
  };
  
  // Filtra histórico baseado na aba ativa
  const filteredHistory = historyData?.filter(entry => {
    if (activeTab === "all") return true;
    return entry.period === activeTab;
  });
  
  // Extrai períodos únicos para exibir nas abas
  const uniquePeriods = historyData 
    ? Array.from(new Set(historyData.map(entry => entry.period)))
        .filter(period => period !== null)
        .sort()
    : [];
    
  return (
    <Card className="bg-card shadow rounded-lg">
      <CardHeader>
        <CardTitle className="gradient-heading">Histórico de Chamadas</CardTitle>
        <CardDescription>
          Registro de presença por dia e período de aula
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 lg:grid-cols-7 mb-4 overflow-x-auto">
            <TabsTrigger value="all">Todos</TabsTrigger>
            {uniquePeriods.map(period => (
              <TabsTrigger key={period} value={period || ""}>
                {period ? `${period}ª Aula` : "Geral"}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value={activeTab} className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-32 w-full" />
                ))}
              </div>
            ) : filteredHistory && filteredHistory.length > 0 ? (
              filteredHistory.map((entry, index) => (
                <div key={`${entry.date}-${entry.period || 'general'}`} 
                  className="p-4 border border-border rounded-lg card-hover bg-white dark:bg-card">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <div className="flex items-center mb-2 md:mb-0">
                      <CalendarDays className="mr-2 h-5 w-5 text-muted-foreground" />
                      <span className="font-medium">{format(new Date(entry.date), 'dd/MM/yyyy')}</span>
                    </div>
                    
                    {entry.period && (
                      <div className="flex items-center">
                        <Clock className="mr-2 h-5 w-5 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{getPeriodLabel(entry.period)}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-col md:flex-row gap-3">
                    <div className="flex-1 rounded-lg p-3 bg-primary/10 flex items-center gap-2">
                      <Users className="h-5 w-5 text-primary" />
                      <div>
                        <div className="text-xs text-muted-foreground">Total de Alunos</div>
                        <div className="font-semibold">{entry.totalStudents}</div>
                      </div>
                    </div>
                    
                    <div className="flex-1 rounded-lg p-3 bg-green-100 dark:bg-green-900/20 flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                      <div>
                        <div className="text-xs text-muted-foreground">Presentes</div>
                        <div className="font-semibold">{entry.presentCount} ({entry.attendancePercent}%)</div>
                      </div>
                    </div>
                    
                    <div className="flex-1 rounded-lg p-3 bg-red-100 dark:bg-red-900/20 flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                      <div>
                        <div className="text-xs text-muted-foreground">Faltas</div>
                        <div className="font-semibold">{entry.absentCount + entry.justifiedCount}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                Nenhum registro de presença encontrado.
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}