import { useState, useEffect } from 'react';
import { useQuery } from "@tanstack/react-query";
import { AttendanceRecord, Student } from '@shared/schema';

type DayAttendance = {
  day: string;
  percentage: number;
};

export function AttendanceChart() {
  const [attendanceData, setAttendanceData] = useState<DayAttendance[]>([
    { day: 'Segunda', percentage: 92 },
    { day: 'Terça', percentage: 88 },
    { day: 'Quarta', percentage: 94 },
    { day: 'Quinta', percentage: 85 },
    { day: 'Sexta', percentage: 78 }
  ]);
  
  // Fetch data
  const { data: attendanceRecords } = useQuery<AttendanceRecord[]>({
    queryKey: ["/api/attendance"]
  });
  
  const { data: students } = useQuery<Student[]>({
    queryKey: ["/api/students"]
  });
  
  // Calculate attendance percentages when data changes
  useEffect(() => {
    if (attendanceRecords && students && students.length > 0) {
      // Map days to their respective indices for consistent ordering
      const dayIndexMap: Record<string, number> = {
        'monday': 0,
        'tuesday': 1,
        'wednesday': 2,
        'thursday': 3,
        'friday': 4
      };
      
      const dayLabelMap: Record<string, string> = {
        'monday': 'Segunda',
        'tuesday': 'Terça',
        'wednesday': 'Quarta',
        'thursday': 'Quinta',
        'friday': 'Sexta'
      };
      
      // Group records by day of week
      const recordsByDay = attendanceRecords.reduce<Record<string, AttendanceRecord[]>>((acc, record) => {
        const date = new Date(record.date);
        const dayOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][date.getDay()];
        
        if (dayOfWeek !== 'saturday' && dayOfWeek !== 'sunday') {
          if (!acc[dayOfWeek]) {
            acc[dayOfWeek] = [];
          }
          acc[dayOfWeek].push(record);
        }
        
        return acc;
      }, {});
      
      // Calculate percentages
      const newData: DayAttendance[] = Object.keys(dayLabelMap).map(day => {
        const dayRecords = recordsByDay[day] || [];
        const totalRecords = dayRecords.length;
        const presentRecords = dayRecords.filter(r => r.status === 'present').length;
        
        const percentage = totalRecords === 0 
          ? 0 
          : Math.round((presentRecords / totalRecords) * 100);
        
        return {
          day: dayLabelMap[day],
          percentage: percentage
        };
      });
      
      // Sort by day index
      newData.sort((a, b) => {
        const aIndex = dayIndexMap[Object.keys(dayLabelMap).find(key => dayLabelMap[key] === a.day) || ''];
        const bIndex = dayIndexMap[Object.keys(dayLabelMap).find(key => dayLabelMap[key] === b.day) || ''];
        return aIndex - bIndex;
      });
      
      if (newData.some(d => d.percentage > 0)) {
        setAttendanceData(newData);
      }
    }
  }, [attendanceRecords, students]);

  return (
    <div className="bg-card shadow rounded-lg p-5">
      <h2 className="text-lg gradient-heading mb-4">Histórico de Presença</h2>
      <div className="h-64 bg-muted/30 rounded-lg flex items-center justify-center">
        <div className="w-full px-5">
          {attendanceData.map((item, index) => (
            <div key={item.day} className={index > 0 ? "mt-4" : ""}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">{item.day}</span>
                <span className="text-sm font-semibold">{item.percentage}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-primary to-accent h-3 rounded-full transition-all duration-500" 
                  style={{ width: `${item.percentage}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
